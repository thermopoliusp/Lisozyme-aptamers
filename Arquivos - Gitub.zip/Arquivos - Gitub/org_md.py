#-*- coding: UTF-8 -*-


from os import system
from math import *

def main():

    system('ls > lista.txt')
    arq = 'lista.txt'

    with open (arq, 'r') as arquivo:
        frases = arquivo.readlines()

    dados = []
    for lin in range(len(frases)):
        separa = frases[lin].split()
        dados.append(separa)

    del separa
    separa = []
    for lin in range(len(dados)):
        for col in range(len(dados[lin])):
            separa.append(dados[lin][col])

    del frases
    del dados

    del separa[0]
    del separa[-1]
    del separa[-1]
    system('rm lista.txt')

    for lin in range(len(separa)):
        com = 'mkdir ' + separa[lin] + '/MD'
        system(com)
        com = 'cp Arquivos_MD/* ' + separa[lin] + '/MD/'
        system(com)
        com = 'mv ' + separa[lin] + '/confout.gro ' +separa[lin] + '/npt.gro'
        system(com)
        com = 'mv ' + separa[lin] + '/state.cpt ' + separa[lin] + '/state_npt.cpt'
        system(com)
        com = 'cp ' + separa[lin] + '/npt.gro ' + separa[lin] + '/state_npt.cpt ' + separa[lin] + '/MD/'
        system(com)
        com = 'vim -c \'%s/XXX/' + separa[lin][4:] + '/g|wq\' ' + separa[lin] + '/MD/job_gromacs.sh'
        system(com)

main()
