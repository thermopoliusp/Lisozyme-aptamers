#!/bin/bash -v
#PBS -S /bin/bash
#PBS -N Jobgromacs
#PBS -l nodes=1:ppn=16
#PBS -l gpus=2
#PBS -l walltime= 249:00:00
#PBS -l cput= 2490:00:00
#PBS -q parallel

date

### cd to directory where the job was submitted:
cd $PBS_O_WORKDIR

### determine the number of allocated processors:
NPROCS=`wc -l < $PBS_NODEFILE`

echo "----------------"
echo "PBS job running on: `hostname`"
echo "in directory:       `pwd`"
echo "cpus: $NPROCS"
echo "gpus: $GPUS"
echo "----------------"

ulimit -s unlimited

module load gromacs/integer-5.1.4

cd /scratch/6850243/Lisozima/4M6D/Minimizacao/NPT/Umbrella/confXXX/MD/

gmx grompp -f md_umb.mdp -c npt.gro -p topol.top -r npt.gro -n index_4m6d.ndx -t state_npt.cpt -o mdXXX.tpr
gmx mdrun -s mdXXX.tpr -deffnm umbrellaXXX -nt 16

# aqui voce inclui os comandos para executar o gromacs...
