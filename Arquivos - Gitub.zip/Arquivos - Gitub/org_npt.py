#-*- coding: UTF-8 -*-

from os import system
from math import *

def main():

    arq = 'distance_4m6d.txt'

    with open (arq, 'r') as arquivo:
        frases = arquivo.readlines()

    dados = []
    for lin in range(len(frases)):
        separa = frases[lin].split()
        dados.append(separa)

    del separa
    separa = []
    for lin in range(len(dados)):
        for col in range(len(dados[lin])):
            separa.append(dados[lin][col])

    del frases
    del dados

    del separa[-1]
    del separa[-1]
    del separa[-1]

    for lin in range(len(separa)):
        com = 'mkdir conf' + separa[lin]
        system(com)
        com = 'cp Arquivos_NPT/* conf' + separa[lin] + '/'
        system(com)
        com = 'cp ../conf' + separa[lin] + '.gro ' + 'conf' + separa[lin] + '/'
        system(com)
        com = 'vim -c \':%s/XXX/' + separa[lin]  + '/g\' -c \':wq\' conf' + separa[lin] + '/job_gromacs.sh'
        system(com)

main()
