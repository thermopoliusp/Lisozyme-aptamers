#-*- coding: UTF-8 -*-

from math import *

def mult_mat(A, B):
    R = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]

    for i in range(len(A)):
        for j in range(len(B[0])):
            for k in range(len(B)):
                R[i][j] = R[i][j] + A[i][k]*B[k][j]

    return R

def main():
    arq = 'newbox.gro'
    with open(arq, 'r') as arquivo:
        frases = arquivo.readlines()

    dados = []
    for lin in range(len(frases)):
        separa = frases[lin].split()
        dados.append(separa)

    del separa
    del frases

    separa = []
    for lin in range(len(dados)):
        for col in range(len(dados[lin])):
            separa.append(dados[lin][col])

    del dados

    angx = float(input('Rotação desejada em x (em graus): '))
    angy = float(input('Rotação desejada em y (em graus): '))
    angz = float(input('Rotação desejada em z (em graus): '))
    angx = angx*pi/180
    angy = angy*pi/180
    angz = angz*pi/180

    #Construamos as matrizes de rotação
    rotx = [[1, 0, 0], [0, cos(angx), -sin(angx)], [0, sin(angx), cos(angx)]]
    roty = [[cos(angy), 0, sin(angy)], [0, 1, 0], [-sin(angy), 0, cos(angy)]]
    rotz = [[cos(angz), -sin(angz), 0], [sin(angz), cos(angz), 0], [0, 0, 1]]

    rot = mult_mat(mult_mat(rotz, roty), rotx)

    #Rotação
    for ind in range(4, len(separa) - 3, 6):
        x = float(separa[ind + 3])*rot[0][0] + float(separa[ind + 4])*rot[0][1] + float(separa[ind + 5])*rot[0][2]
        y = float(separa[ind + 3])*rot[1][0] + float(separa[ind + 4])*rot[1][1] - float(separa[ind + 5])*rot[1][2]
        z = float(separa[ind + 3])*rot[2][0] + float(separa[ind + 4])*rot[2][1] + float(separa[ind + 5])*rot[2][2]
        
        separa[ind + 3] = round(x, 3)
        separa[ind + 4] = round(y, 3)
        separa[ind + 5] = round(z, 3)
    
    arq = open('resp.gro', 'w')
    arq.write(separa[0] + ' ' + separa[1] + ' ' + separa[2] + '\n')
    arq.write(' ' + separa[3] + '\n')

    for ind in range(4, len(separa) - 3, 6):
        arq.write('%8s%7s%5s%8.3f%8.3f%8.3f\n' %(separa[ind], separa[ind + 1], separa[ind + 2], separa[ind + 3], separa[ind + 4], separa[ind + 5]))
    arq.write('%10s%10s%10s' %(separa[len(separa) - 3], separa[len(separa) - 2], separa[len(separa) - 1]))

main()
