#-*- coding: UTF-8 -*-


from os import system
from math import *

def main():

    system('ls > lista.txt')
    arq = 'lista.txt'

    with open (arq, 'r') as arquivo:
        frases = arquivo.readlines()

    dados = []
    for lin in range(len(frases)):
        separa = frases[lin].split()
        dados.append(separa)

    del separa
    separa = []
    for lin in range(len(dados)):
        for col in range(len(dados[lin])):
            separa.append(dados[lin][col])

    del frases
    del dados

    del separa[0]
    del separa[-1]
    del separa[-1]
    del separa[-1]
    system('rm lista.txt')
    system('mkdir WHAM')
    system('mkdir WHAM/tpr')
    system('mkdir WHAM/pull')

    for lin in range(len(separa)):
        com = 'cp ' + separa[lin] + '/MD/md' + separa[lin][4:] + '.tpr WHAM/tpr/'
        system(com)
        com = 'cp ' + separa[lin] + '/MD/umbrella' + separa[lin][4:] + '_pullf.xvg WHAM/pull/'
        system(com)
        
main()
